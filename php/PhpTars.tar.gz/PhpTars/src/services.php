<?php
return [
    'testObj' => [
        'home-api' => '\PhpTars\servant\TestUnits\PhpTars\testObj\testServant',
        'home-class' => '\PhpTars\impl\test',
        'protocolName' => 'tars',
        'serverType' => 'tcp',
    ],
];
