<?php
return array(
    'appName' => 'TestUnits',
    'serverName' => 'PhpTars',
    'objName' => 'testObj',
    'withServant' => true,
    'tarsFiles' => array(
        './php.tars',
    ),
    'dstPath' => '../src/servant',
    'namespacePrefix' => 'PhpTars\servant',
);
